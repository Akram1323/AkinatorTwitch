package akinator.game;

import java.sql.*;
import java.util.*;

public class GameTree {
    private static ChoixNode rootNode = new ChoixNode("Vous recherchez ?");
    private static final Map<Integer, ChoixNode> nodeMap = new HashMap<>();

    public static void buildTreeFromDatabase(Connection conn) throws SQLException {
        nodeMap.clear();
        nodeMap.put(0, rootNode);

        String query = "SELECT id, question_text, profondeur, parent_id FROM questions";
        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String question = rs.getString("question_text");
                int profondeur = rs.getInt("profondeur");
                int parentId = rs.getInt("parent_id");

                ChoixNode node = new ChoixNode(id, question, profondeur);
                nodeMap.put(id, node);

                if (nodeMap.containsKey(parentId)) {
                    nodeMap.get(parentId).addChild(node);
                }
            }
        }
    }

    public static List<ChoixNode> getChildrenAtDepth(int depth, List<String> path) {
        ChoixNode current = rootNode;
        for (String label : path) {
            Optional<ChoixNode> next = current.getListChildNodes().stream()
                .filter(c -> c.getDecision().equalsIgnoreCase(label))
                .findFirst();
            if (next.isPresent()) {
                current = next.get();
            } else {
                return Collections.emptyList();
            }
        }
        return current.getListChildNodes();
    }

    public static ChoixNode getRootNode() {
        return rootNode;
    }
}