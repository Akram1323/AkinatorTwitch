package akinator.game;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class DynamicAkinatorView extends JFrame {

    private int currentDepth = 0;
    private final int maxDepth = 4;
    private final List<bdd.Question> appliedFilters = new ArrayList<>();

    private JPanel buttonsPanel;
    private JLabel questionLabel;
    private JTextArea filtersArea;
    private JTextArea recommendationsArea;
    private JButton backButton;

    public DynamicAkinatorView(Connection conn) {
        super("Akinator Dynamique");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        questionLabel = new JLabel("", SwingConstants.CENTER);
        questionLabel.setFont(new Font("Arial", Font.BOLD, 16));

        filtersArea = new JTextArea(2, 50);
        filtersArea.setEditable(false);
        filtersArea.setLineWrap(true);

        recommendationsArea = new JTextArea(4, 50);
        recommendationsArea.setEditable(false);
        recommendationsArea.setLineWrap(true);

        buttonsPanel = new JPanel(new GridLayout(0, 1, 10, 10));

        backButton = new JButton("Retour");
        backButton.setEnabled(false);
        backButton.addActionListener(e -> {
            if (currentDepth > 0) {
                currentDepth--;
                if (!appliedFilters.isEmpty()) {
                    appliedFilters.remove(appliedFilters.size() - 1);
                }
                updateView();
            }
        });

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(questionLabel, BorderLayout.CENTER);
        topPanel.add(backButton, BorderLayout.WEST);

        getContentPane().setLayout(new BorderLayout(10, 10));
        getContentPane().add(topPanel, BorderLayout.NORTH);
        getContentPane().add(new JScrollPane(buttonsPanel), BorderLayout.CENTER);
        getContentPane().add(new JScrollPane(filtersArea), BorderLayout.WEST);
        getContentPane().add(new JScrollPane(recommendationsArea), BorderLayout.SOUTH);

        updateView();
        setVisible(true);
    }

    private void updateView() {
        buttonsPanel.removeAll();
        filtersArea.setText(String.join(" > ", appliedFilters.stream().map(bdd.Question::getText).toList()));
        recommendationsArea.setText("");

        if (currentDepth == 0) {
            questionLabel.setText("Vous recherchez ?");
            JButton btn = new JButton("Un jeu");
            btn.addActionListener(e -> {
                appliedFilters.add(new bdd.Question(-1, "Un jeu", -1, 0));
                currentDepth++;
                updateView();
            });
            buttonsPanel.add(btn);

        } else if (currentDepth <= maxDepth) {
            questionLabel.setText("Choisissez une catégorie :");
            List<bdd.Question> questions = bdd.getQuestionsByDepth(currentDepth);

            for (bdd.Question q : questions) {
                JButton btn = new JButton(q.getText());
                btn.addActionListener(e -> {
                    appliedFilters.add(q);
                    currentDepth++;
                    updateView();
                });
                buttonsPanel.add(btn);
            }

            JButton recommendNow = new JButton("Voir les recommandations maintenant");
            recommendNow.addActionListener(e -> showRecommendations());
            buttonsPanel.add(recommendNow);

        } else {
            showRecommendations();
        }

        backButton.setEnabled(currentDepth > 0);
        buttonsPanel.revalidate();
        buttonsPanel.repaint();
    }

    private void showRecommendations() {
        StringBuilder sb = new StringBuilder();
        sb.append("Recommandations pour : \n");
        for (bdd.Question q : appliedFilters) {
            sb.append("- ").append(q.getText()).append("\n");
        }

        List<String> games = IGDBClient.searchGamesByStructuredFilters(appliedFilters);

        if (games.isEmpty()) {
            sb.append("\nAucune recommandation trouvée sur IGDB.");
        } else {
            sb.append("\nJeux recommandés :\n");
            for (String game : games) {
                sb.append("- ").append(game).append("\n");
            }
        }

        recommendationsArea.setText(sb.toString());
    }
}
