package akinator.game;

import java.util.*;

public class ChoixNode {
    private int id;
    private int profondeur;
    private String decision;
    private List<ChoixNode> children;
    private List<String> recommendedGames;

    public ChoixNode(int id, String decision, int profondeur) {
        this.id = id;
        this.decision = decision;
        this.profondeur = profondeur;
        this.children = new ArrayList<>();
        this.recommendedGames = new ArrayList<>();
    }

    public ChoixNode(String decision) {
        this(-1, decision, 0);
    }

    public void addChild(ChoixNode node) {
        children.add(node);
    }

    public void addRecommendedGame(String game) {
        recommendedGames.add(game);
    }

    public List<ChoixNode> getListChildNodes() {
        return children;
    }

    public String getDecision() {
        return decision;
    }

    public List<String> getRecommendedGames() {
        return recommendedGames;
    }

    public int getProfondeur() {
        return profondeur;
    }

    public String getQuestion() {
        return decision;
    }
}